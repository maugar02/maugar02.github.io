#ifndef BUFFER_HPP
#define BUFFER_HPP

#include <string>

namespace mgu
{
    enum TW
    {
        LR = 0x9, /* Remplazando una l�nea */
        F,        /* A�adiendo una linea al final */
        A,        /* A�adiendo una linea en la l�nea especificada */
    };
    class buffer
    {
    public:
        buffer();
        ~buffer();
        void Load(std::string data);                                  //
        std::string GetLine(unsigned int line);                       //
        bool WriteLine(std::string data, TW tipo, unsigned int line); //
        bool DeleteLine(unsigned int line);                           //
        unsigned int Getbzise();
        unsigned int GetNlines(); //
        std::string GetBuffer();  //
        void ClearBuffer();
    private:
        void CalculateLines(); //
        std::string ab;        // Principal
        unsigned int nlines;
        unsigned int cursol;
    };
}

#endif // BUFFER_HPP
